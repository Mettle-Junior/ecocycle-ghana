import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
data_dir = os.environ.get("ANDROID_DATA_DIR", BASE_DIR)
db_path = os.path.join(data_dir, "ecocycle.db")

class Config:
    SECRET_KEY = "ecocycle_secret_key_2026"
    SQLALCHEMY_DATABASE_URI = f"sqlite:///{db_path}"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
